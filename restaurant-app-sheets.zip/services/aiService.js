import axios from "axios"

const OPENAI_API_KEY = process.env.EXPO_PUBLIC_OPENAI_API_KEY
const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"

// Obtener recomendaciones personalizadas
export const getAIRecommendations = async (userPreferences, restaurants) => {
  try {
    const prompt = `
      Basándote en las siguientes preferencias del usuario: ${userPreferences.join(", ")}
      Y estos restaurantes disponibles: ${JSON.stringify(restaurants)}
      
      Proporciona 3 recomendaciones personalizadas en formato JSON con los campos:
      - restaurantId
      - reason (razón de la recomendación)
      - matchScore (puntuación de 0-100)
      
      Responde solo con el JSON, sin explicaciones adicionales.
    `

    const response = await axios.post(
      OPENAI_API_URL,
      {
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    const content = response.data.choices[0].message.content
    return JSON.parse(content)
  } catch (error) {
    console.error("Error obteniendo recomendaciones de IA:", error)
    throw error
  }
}

// Generar descripción de restaurante con IA
export const generateRestaurantDescription = async (restaurantName, cuisine) => {
  try {
    const prompt = `Genera una descripción atractiva y breve (máximo 100 palabras) para un restaurante de comida ${cuisine} llamado ${restaurantName}. La descripción debe ser persuasiva y mencionar lo que lo hace especial.`

    const response = await axios.post(
      OPENAI_API_URL,
      {
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    return response.data.choices[0].message.content
  } catch (error) {
    console.error("Error generando descripción:", error)
    throw error
  }
}
