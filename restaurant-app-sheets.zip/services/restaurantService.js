import { collection, query, where, getDocs, doc, getDoc, addDoc } from "firebase/firestore"
import { db } from "./firebaseConfig"

// Obtener todos los restaurantes
export const getAllRestaurants = async () => {
  try {
    const restaurantsRef = collection(db, "restaurantes")
    const snapshot = await getDocs(restaurantsRef)
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))
  } catch (error) {
    console.error("Error obteniendo restaurantes:", error)
    throw error
  }
}

// Obtener restaurantes por categoría
export const getRestaurantsByCategory = async (category) => {
  try {
    const restaurantsRef = collection(db, "restaurantes")
    const q = query(restaurantsRef, where("category", "==", category))
    const snapshot = await getDocs(q)
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))
  } catch (error) {
    console.error("Error obteniendo restaurantes por categoría:", error)
    throw error
  }
}

// Obtener detalles de un restaurante
export const getRestaurantDetail = async (restaurantId) => {
  try {
    const docRef = doc(db, "restaurantes", restaurantId)
    const docSnap = await getDoc(docRef)
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() }
    } else {
      throw new Error("Restaurante no encontrado")
    }
  } catch (error) {
    console.error("Error obteniendo detalles del restaurante:", error)
    throw error
  }
}

// Agregar restaurante a favoritos
export const addToFavorites = async (userId, restaurantId) => {
  try {
    const favoritesRef = collection(db, "favoritos")
    await addDoc(favoritesRef, {
      userId,
      restaurantId,
      createdAt: new Date(),
    })
  } catch (error) {
    console.error("Error agregando a favoritos:", error)
    throw error
  }
}

// Obtener favoritos del usuario
export const getUserFavorites = async (userId) => {
  try {
    const favoritesRef = collection(db, "favoritos")
    const q = query(favoritesRef, where("userId", "==", userId))
    const snapshot = await getDocs(q)
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))
  } catch (error) {
    console.error("Error obteniendo favoritos:", error)
    throw error
  }
}
