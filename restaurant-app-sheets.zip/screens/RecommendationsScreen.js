"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { getAllRestaurants } from "../services/restaurantService"
import { getAIRecommendations as getAIRecs } from "../services/aiService"

export default function RecommendationsScreen({ navigation }) {
  const [recommendations, setRecommendations] = useState([])
  const [loading, setLoading] = useState(true)
  const [userPreferences, setUserPreferences] = useState(["Italiana", "Japonesa"])

  useEffect(() => {
    loadRecommendations()
  }, [])

  const loadRecommendations = async () => {
    try {
      setLoading(true)
      // Obtener todos los restaurantes
      const restaurants = await getAllRestaurants()

      // Obtener recomendaciones de IA
      const aiRecs = await getAIRecs(userPreferences, restaurants)

      // Mapear recomendaciones con datos de restaurantes
      const enrichedRecs = aiRecs.map((rec) => {
        const restaurant = restaurants.find((r) => r.id === rec.restaurantId)
        return {
          ...rec,
          ...restaurant,
        }
      })

      setRecommendations(enrichedRecs)
    } catch (error) {
      console.error("Error cargando recomendaciones:", error)
      Alert.alert("Error", "No se pudieron cargar las recomendaciones")
    } finally {
      setLoading(false)
    }
  }

  const renderRecommendation = ({ item, index }) => (
    <TouchableOpacity
      style={styles.recommendationCard}
      onPress={() => navigation.navigate("RestaurantDetail", { restaurant: item })}
    >
      <View style={styles.rankBadge}>
        <Text style={styles.rankText}>#{index + 1}</Text>
      </View>

      <View style={styles.cardContent}>
        <Text style={styles.restaurantName}>{item.name}</Text>
        <Text style={styles.category}>{item.category}</Text>

        <View style={styles.matchScoreContainer}>
          <View style={styles.scoreBar}>
            <View style={[styles.scoreBarFill, { width: `${item.matchScore}%` }]} />
          </View>
          <Text style={styles.scoreText}>{item.matchScore}% Match</Text>
        </View>

        <Text style={styles.reason}>{item.reason}</Text>

        <View style={styles.footer}>
          <View style={styles.ratingBox}>
            <Ionicons name="star" size={16} color="#FFB800" />
            <Text style={styles.rating}>{item.rating || 4.5}</Text>
          </View>
          <TouchableOpacity style={styles.viewButton}>
            <Text style={styles.viewButtonText}>Ver Detalles</Text>
            <Ionicons name="arrow-forward" size={16} color="#FF6B35" />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  )

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B35" />
        <Text style={styles.loadingText}>Generando recomendaciones personalizadas...</Text>
      </View>
    )
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Recomendaciones Personalizadas</Text>
        <Text style={styles.headerSubtitle}>Basadas en tus preferencias</Text>
      </View>

      <View style={styles.preferencesContainer}>
        <Text style={styles.preferencesLabel}>Tus preferencias:</Text>
        <View style={styles.preferencesRow}>
          {userPreferences.map((pref, index) => (
            <View key={index} style={styles.preferenceTag}>
              <Text style={styles.preferenceTagText}>{pref}</Text>
            </View>
          ))}
          <TouchableOpacity style={styles.editButton}>
            <Ionicons name="pencil" size={16} color="#FF6B35" />
          </TouchableOpacity>
        </View>
      </View>

      {recommendations.length > 0 ? (
        <View style={styles.recommendationsContainer}>
          {recommendations.map((rec, index) => (
            <View key={rec.id || index}>{renderRecommendation({ item: rec, index })}</View>
          ))}
        </View>
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="search" size={48} color="#DDD" />
          <Text style={styles.emptyText}>No hay recomendaciones disponibles</Text>
        </View>
      )}

      <TouchableOpacity style={styles.refreshButton} onPress={loadRecommendations}>
        <Ionicons name="refresh" size={20} color="#FFF" />
        <Text style={styles.refreshButtonText}>Obtener Nuevas Recomendaciones</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFF",
  },
  loadingText: {
    marginTop: 15,
    fontSize: 14,
    color: "#999",
  },
  header: {
    backgroundColor: "#FF6B35",
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFF",
  },
  headerSubtitle: {
    fontSize: 14,
    color: "#FFE8D6",
    marginTop: 5,
  },
  preferencesContainer: {
    backgroundColor: "#FFF",
    marginHorizontal: 10,
    marginVertical: 15,
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 12,
  },
  preferencesLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    marginBottom: 10,
  },
  preferencesRow: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },
  preferenceTag: {
    backgroundColor: "#FFE8D6",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  preferenceTagText: {
    color: "#FF6B35",
    fontSize: 12,
    fontWeight: "500",
  },
  editButton: {
    padding: 8,
  },
  recommendationsContainer: {
    paddingHorizontal: 10,
    paddingBottom: 20,
  },
  recommendationCard: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    marginBottom: 15,
    overflow: "hidden",
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  rankBadge: {
    position: "absolute",
    top: 10,
    right: 10,
    backgroundColor: "#FF6B35",
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 10,
  },
  rankText: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 14,
  },
  cardContent: {
    padding: 15,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  category: {
    fontSize: 14,
    color: "#999",
    marginBottom: 12,
  },
  matchScoreContainer: {
    marginBottom: 12,
  },
  scoreBar: {
    height: 6,
    backgroundColor: "#EEE",
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: 6,
  },
  scoreBarFill: {
    height: "100%",
    backgroundColor: "#FF6B35",
  },
  scoreText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#FF6B35",
  },
  reason: {
    fontSize: 13,
    color: "#666",
    lineHeight: 18,
    marginBottom: 12,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  ratingBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFF3E0",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  rating: {
    marginLeft: 5,
    fontSize: 14,
    fontWeight: "bold",
    color: "#333",
  },
  viewButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  viewButtonText: {
    color: "#FF6B35",
    fontSize: 12,
    fontWeight: "600",
    marginRight: 5,
  },
  emptyContainer: {
    alignItems: "center",
    paddingVertical: 40,
  },
  emptyText: {
    marginTop: 15,
    fontSize: 16,
    color: "#999",
  },
  refreshButton: {
    backgroundColor: "#FF6B35",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 20,
    marginVertical: 20,
    paddingVertical: 14,
    borderRadius: 8,
  },
  refreshButtonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 8,
  },
})
