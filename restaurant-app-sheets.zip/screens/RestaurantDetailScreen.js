"use client"

import { useState } from "react"
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"

export default function RestaurantDetailScreen({ route, navigation }) {
  const { restaurant } = route.params
  const [isFavorite, setIsFavorite] = useState(false)

  const handleReview = () => {
    navigation.navigate("Reviews", { restaurantId: restaurant.id })
  }

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: restaurant.image }} style={styles.headerImage} />

      <TouchableOpacity style={styles.closeButton} onPress={() => navigation.goBack()}>
        <Ionicons name="close" size={24} color="#FFF" />
      </TouchableOpacity>

      <View style={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={styles.name}>{restaurant.name}</Text>
            <Text style={styles.category}>{restaurant.category}</Text>
          </View>
          <TouchableOpacity onPress={() => setIsFavorite(!isFavorite)}>
            <Ionicons name={isFavorite ? "heart" : "heart-outline"} size={28} color={isFavorite ? "#FF6B35" : "#999"} />
          </TouchableOpacity>
        </View>

        <View style={styles.ratingSection}>
          <View style={styles.ratingBox}>
            <Ionicons name="star" size={20} color="#FFB800" />
            <Text style={styles.ratingText}>{restaurant.rating}</Text>
          </View>
          <Text style={styles.distance}>{restaurant.distance}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ubicación</Text>
          <Text style={styles.sectionContent}>{restaurant.address}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Descripción</Text>
          <Text style={styles.sectionContent}>
            Excelente restaurante con comida de calidad, ambiente acogedor y servicio atento. Perfecto para cenas en
            familia o con amigos.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Horario</Text>
          <Text style={styles.sectionContent}>Lunes - Domingo: 11:00 AM - 11:00 PM</Text>
        </View>

        <TouchableOpacity style={styles.reviewButton} onPress={handleReview}>
          <Ionicons name="chatbubble-outline" size={20} color="#FFF" />
          <Text style={styles.reviewButtonText}>Ver Reseñas</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.callButton} onPress={() => Alert.alert("Llamar", "+1 234 567 8900")}>
          <Ionicons name="call-outline" size={20} color="#FFF" />
          <Text style={styles.callButtonText}>Llamar</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  headerImage: {
    width: "100%",
    height: 250,
  },
  closeButton: {
    position: "absolute",
    top: 10,
    left: 10,
    backgroundColor: "rgba(0,0,0,0.5)",
    borderRadius: 20,
    padding: 8,
  },
  content: {
    padding: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 15,
  },
  name: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  category: {
    fontSize: 14,
    color: "#999",
    marginTop: 5,
  },
  ratingSection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  ratingBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFF3E0",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 15,
  },
  ratingText: {
    marginLeft: 5,
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
  },
  distance: {
    fontSize: 14,
    color: "#999",
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 8,
  },
  sectionContent: {
    fontSize: 14,
    color: "#666",
    lineHeight: 20,
  },
  reviewButton: {
    backgroundColor: "#FF6B35",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
    borderRadius: 8,
    marginBottom: 10,
  },
  reviewButtonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 8,
  },
  callButton: {
    backgroundColor: "#4CAF50",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
    borderRadius: 8,
  },
  callButtonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 8,
  },
})
