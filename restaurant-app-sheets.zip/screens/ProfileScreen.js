"use client"

import { useState } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"

export default function ProfileScreen() {
  const [notifications, setNotifications] = useState(true)
  const [darkMode, setDarkMode] = useState(false)

  const handleLogout = () => {
    Alert.alert("Cerrar Sesión", "¿Estás seguro de que deseas cerrar sesión?", [
      { text: "Cancelar", onPress: () => {} },
      { text: "Cerrar Sesión", onPress: () => {} },
    ])
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.profileHeader}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={50} color="#FF6B35" />
        </View>
        <Text style={styles.userName}>Juan Pérez</Text>
        <Text style={styles.userEmail}>juan@example.com</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferencias</Text>

        <View style={styles.preferenceItem}>
          <View style={styles.preferenceLeft}>
            <Ionicons name="notifications" size={20} color="#FF6B35" />
            <Text style={styles.preferenceText}>Notificaciones</Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: "#DDD", true: "#FF6B35" }}
          />
        </View>

        <View style={styles.preferenceItem}>
          <View style={styles.preferenceLeft}>
            <Ionicons name="moon" size={20} color="#FF6B35" />
            <Text style={styles.preferenceText}>Modo Oscuro</Text>
          </View>
          <Switch value={darkMode} onValueChange={setDarkMode} trackColor={{ false: "#DDD", true: "#FF6B35" }} />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Mis Preferencias Culinarias</Text>
        <View style={styles.tagsContainer}>
          <View style={styles.tag}>
            <Text style={styles.tagText}>Italiana</Text>
          </View>
          <View style={styles.tag}>
            <Text style={styles.tagText}>Japonesa</Text>
          </View>
          <View style={styles.tag}>
            <Text style={styles.tagText}>Mexicana</Text>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Información</Text>

        <TouchableOpacity style={styles.infoItem}>
          <Ionicons name="help-circle-outline" size={20} color="#FF6B35" />
          <Text style={styles.infoText}>Ayuda y Soporte</Text>
          <Ionicons name="chevron-forward" size={20} color="#DDD" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.infoItem}>
          <Ionicons name="document-text-outline" size={20} color="#FF6B35" />
          <Text style={styles.infoText}>Términos y Condiciones</Text>
          <Ionicons name="chevron-forward" size={20} color="#DDD" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.infoItem}>
          <Ionicons name="shield-checkmark-outline" size={20} color="#FF6B35" />
          <Text style={styles.infoText}>Política de Privacidad</Text>
          <Ionicons name="chevron-forward" size={20} color="#DDD" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={20} color="#FFF" />
        <Text style={styles.logoutText}>Cerrar Sesión</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },
  profileHeader: {
    alignItems: "center",
    paddingVertical: 30,
    backgroundColor: "#FFF",
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#FFE8D6",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },
  userName: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  userEmail: {
    fontSize: 14,
    color: "#999",
    marginTop: 5,
  },
  section: {
    backgroundColor: "#FFF",
    marginTop: 15,
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 15,
  },
  preferenceItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
  },
  preferenceLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  preferenceText: {
    marginLeft: 12,
    fontSize: 16,
    color: "#333",
  },
  tagsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  tag: {
    backgroundColor: "#FFE8D6",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
    marginBottom: 10,
  },
  tagText: {
    color: "#FF6B35",
    fontSize: 14,
    fontWeight: "500",
  },
  infoItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
  },
  infoText: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: "#333",
  },
  logoutButton: {
    backgroundColor: "#FF6B35",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 20,
    marginVertical: 30,
    paddingVertical: 14,
    borderRadius: 8,
  },
  logoutText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 8,
  },
})
