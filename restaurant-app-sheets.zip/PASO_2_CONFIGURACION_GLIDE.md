# PASO 2: CONFIGURACIÓN DE GLIDE - GUÍA COMPLETA

## Introducción
Glide es una plataforma sin código que permite crear aplicaciones móviles profesionales conectadas a Google Sheets. En este paso configuraremos tu app de restaurantes desde cero.

---

## PARTE 1: CREAR PROYECTO EN GLIDE

### 1.1 Registro e Inicio
1. Ve a **glide.app** y crea una cuenta (o inicia sesión)
2. Haz clic en **"Create an app"** o **"New app"**
3. Selecciona **"Blank app"** (aplicación en blanco)
4. Elige **"Mobile app"** (aplicación móvil)
5. Dale un nombre: **"LocalMatch"** (o el nombre que prefieras)
6. Haz clic en **"Create"**

### 1.2 Pantalla Inicial de Glide
Una vez creado el proyecto, verás:
- **Editor visual** (izquierda) - Diseña las pantallas
- **Componentes** (centro) - Arrastra elementos
- **Propiedades** (derecha) - Configura cada elemento

---

## PARTE 2: CONECTAR GOOGLE SHEETS

### 2.1 Conectar tu Google Sheet
1. En Glide, ve a **"Data"** (arriba a la izquierda)
2. Haz clic en **"Connect"** o **"Add data source"**
3. Selecciona **"Google Sheets"**
4. Autoriza a Glide a acceder a tu cuenta de Google
5. Selecciona el Google Sheet que creaste con las tablas

### 2.2 Importar Tablas
Glide debería detectar automáticamente tus hojas:
- **usuarios**
- **restaurantes**
- **resenas**
- **historial_interacciones**

Si no aparecen:
1. Haz clic en **"Add table"**
2. Selecciona cada hoja manualmente
3. Glide creará una tabla por cada hoja

### 2.3 Configurar Relaciones entre Tablas
1. Ve a la tabla **"restaurantes"**
2. Haz clic en el ícono de engranaje (⚙️) en la columna **"id_restaurante"**
3. Selecciona **"Link to table"** → **"resenas"**
4. Repite para conectar **usuarios** con **historial_interacciones**

---

## PARTE 3: AUTENTICACIÓN OTP (ONE-TIME PASSWORD)

### 3.1 Configurar Autenticación
1. Ve a **"Settings"** (engranaje arriba a la derecha)
2. Selecciona **"Authentication"**
3. Activa **"User Profiles"** (Perfiles de Usuario)
4. Elige **"Email"** como método de autenticación
5. Haz clic en **"Save"**

### 3.2 Crear Pantalla de Login
1. Haz clic en **"+"** para crear una nueva pantalla
2. Selecciona **"Blank screen"**
3. Nombra la pantalla: **"Login"**
4. En el editor, arrastra estos componentes:
   - **Text** - Título: "Bienvenido a LocalMatch"
   - **Text Input** - Placeholder: "Correo electrónico"
   - **Button** - Texto: "Enviar código OTP"

### 3.3 Configurar Lógica de OTP
1. Selecciona el **Button** "Enviar código OTP"
2. En la sección **"Actions"** (derecha), haz clic en **"Add action"**
3. Selecciona **"Sign in with email"**
4. Configura:
   - **Email field**: Selecciona el Text Input de correo
   - **Redirect to**: Selecciona la pantalla "Perfil" (la crearemos después)

### 3.4 Crear Pantalla de Verificación OTP
1. Crea una nueva pantalla: **"Verify OTP"**
2. Arrastra:
   - **Text** - "Ingresa el código que recibiste"
   - **Text Input** - Placeholder: "Código OTP"
   - **Button** - "Verificar"
3. Configura el botón para verificar el código y redirigir a "Perfil"

---

## PARTE 4: CREAR PANTALLAS PRINCIPALES

### 4.1 Pantalla de Perfil y Preferencias
**Nombre**: "Perfil"

**Componentes**:
1. **Header** (Encabezado)
   - Texto: "Mi Perfil"
   - Fondo: Color primario

2. **User Info** (Información del Usuario)
   - Nombre del usuario (conectado a tabla usuarios)
   - Email (conectado a tabla usuarios)

3. **Preferencias** (Sección de Preferencias)
   - **Toggle** - "Comida Italiana"
   - **Toggle** - "Comida Mexicana"
   - **Toggle** - "Comida Asiática"
   - **Toggle** - "Comida Rápida"
   - **Toggle** - "Vegetariano"

4. **Rango de Precio**
   - **Slider** - Rango: $-$$$$

5. **Botón**
   - Texto: "Guardar Preferencias"
   - Acción: Actualizar tabla usuarios

6. **Botón**
   - Texto: "Ir al Mapa"
   - Acción: Navegar a pantalla "Mapa"

---

### 4.2 Pantalla de Mapa
**Nombre**: "Mapa"

**Componentes**:
1. **Header**
   - Texto: "Restaurantes Cercanos"
   - Botón: "Filtros" (navega a "Filtros")

2. **Map Component** (Mapa)
   - Conecta a tabla: **restaurantes**
   - Latitud: columna "latitud"
   - Longitud: columna "longitud"
   - Título del marcador: "nombre"
   - Haz clic en marcador → navega a "Detalles Restaurante"

3. **List** (Lista debajo del mapa)
   - Muestra: Nombre, categoría, calificación
   - Conecta a tabla: **restaurantes**
   - Haz clic en item → navega a "Detalles Restaurante"

---

### 4.3 Pantalla de Detalles del Restaurante
**Nombre**: "Detalles Restaurante"

**Componentes**:
1. **Image** - Foto del restaurante
2. **Text** - Nombre del restaurante
3. **Text** - Dirección
4. **Text** - Teléfono
5. **Rating** - Calificación (estrellas)
6. **Text** - Descripción
7. **Button** - "Agregar a Favoritos"
8. **Button** - "Ver Reseñas"
9. **Button** - "Volver"

**Configuración**:
- Conecta todos los campos a la tabla **restaurantes**
- El botón "Ver Reseñas" navega a "Reseñas"
- El botón "Agregar a Favoritos" actualiza **historial_interacciones**

---

### 4.4 Pantalla de Reseñas
**Nombre**: "Reseñas"

**Componentes**:
1. **Header** - "Reseñas del Restaurante"
2. **List** - Conecta a tabla **resenas**
   - Muestra: Usuario, calificación, comentario, fecha
3. **Text Input** - Placeholder: "Escribe tu reseña"
4. **Rating** - Selector de calificación (1-5 estrellas)
5. **Button** - "Enviar Reseña"
   - Acción: Agregar fila a tabla **resenas**

---

### 4.5 Pantalla de Filtros
**Nombre**: "Filtros"

**Componentes**:
1. **Header** - "Filtrar Restaurantes"
2. **Checkboxes** (Categorías)
   - Italiana
   - Mexicana
   - Asiática
   - Rápida
   - Vegetariana
3. **Slider** - Rango de precio
4. **Slider** - Calificación mínima
5. **Button** - "Aplicar Filtros"
   - Acción: Volver a "Mapa" con filtros aplicados
6. **Button** - "Limpiar Filtros"

---

## PARTE 5: CONFIGURAR NAVEGACIÓN

### 5.1 Crear Menú de Navegación
1. Ve a **"Navigation"** (arriba)
2. Selecciona **"Tab bar"** (barra de pestañas)
3. Configura 4 pestañas:
   - **Mapa** → Pantalla "Mapa"
   - **Favoritos** → Pantalla "Favoritos" (crearemos después)
   - **Historial** → Pantalla "Historial"
   - **Perfil** → Pantalla "Perfil"

### 5.2 Flujo de Navegación
\`\`\`
Login → Verify OTP → Mapa (pantalla principal)
                  ↓
            ├─ Mapa (con Tab Bar)
            ├─ Favoritos
            ├─ Historial
            └─ Perfil
                  ↓
            Detalles Restaurante
                  ↓
            Reseñas
\`\`\`

---

## PARTE 6: PRUEBAS Y AJUSTES

### 6.1 Probar la App
1. Haz clic en **"Preview"** (arriba a la derecha)
2. Prueba el flujo completo:
   - Inicia sesión con tu correo
   - Verifica el OTP
   - Navega por el mapa
   - Haz clic en un restaurante
   - Lee y escribe reseñas

### 6.2 Ajustes Comunes
- Si los mapas no cargan: Verifica que latitud/longitud estén en formato correcto
- Si las reseñas no se guardan: Asegúrate de que la tabla **resenas** esté conectada
- Si la autenticación falla: Verifica que User Profiles esté habilitado

---

## PRÓXIMOS PASOS

Una vez completado este paso:
1. Verifica que todas las pantallas funcionen correctamente
2. Prueba la autenticación OTP
3. Confirma que los datos se guardan en Google Sheets
4. Prepárate para el **Paso 3: Integración de IA** (recomendaciones personalizadas)

---

## RECURSOS ÚTILES

- Documentación oficial de Glide: https://www.glideapps.com/docs
- Comunidad de Glide: https://community.glideapps.com
- Tutoriales en YouTube: Busca "Glide tutorial" en español

---

**¿Necesitas ayuda con algún paso específico? Avísame y te guiaré.**
