# Paso 2: Configuración de FlutterFlow - Guía Completa

## Introducción a FlutterFlow

FlutterFlow es una plataforma sin código basada en Flutter que permite crear aplicaciones móviles profesionales sin escribir código. Es perfecta para tu app de restaurantes porque:

- Plan gratuito completo
- Integración con Google Sheets
- Mapas integrados
- Autenticación OTP
- APIs REST para IA
- Exportación a código Flutter si lo necesitas

---

## PARTE 1: Crear Proyecto en FlutterFlow

### Paso 1.1: Registrarse en FlutterFlow
1. Ve a **flutterflow.io**
2. Haz clic en **"Sign Up"**
3. Crea cuenta con email o Google
4. Verifica tu email
5. Completa el perfil básico

### Paso 1.2: Crear Nuevo Proyecto
1. En el dashboard, haz clic en **"+ New Project"**
2. Selecciona **"Blank Project"**
3. Nombre: **"LocalMatch"** (o el nombre de tu app)
4. Selecciona **"Mobile"** como tipo
5. Haz clic en **"Create"**

### Paso 1.3: Familiarizarse con la Interfaz
- **Canvas**: Área central donde diseñas
- **Component Tree**: Panel izquierdo con estructura
- **Inspector**: Panel derecho con propiedades
- **Toolbar**: Herramientas en la parte superior

---

## PARTE 2: Conectar Google Sheets

### Paso 2.1: Preparar Google Sheets
1. Abre tu Google Sheet con los datos de restaurantes
2. Asegúrate de que las hojas tengan estos nombres exactos:
   - `usuarios`
   - `restaurantes`
   - `resenas`
   - `historial_interacciones`
3. Comparte el Sheet: **Cualquiera con el enlace puede ver**

### Paso 2.2: Conectar en FlutterFlow
1. En FlutterFlow, ve a **"Backend"** (parte superior)
2. Haz clic en **"+ Add Backend Resource"**
3. Selecciona **"Google Sheets"**
4. Haz clic en **"Authenticate"**
5. Selecciona tu cuenta de Google
6. Autoriza FlutterFlow
7. Selecciona tu Google Sheet
8. Haz clic en **"Confirm"**

### Paso 2.3: Crear Queries (Consultas)
FlutterFlow creará automáticamente queries para cada hoja. Verifica que existan:

**Query: Get All Restaurants**
- Tabla: `restaurantes`
- Tipo: Get All Rows
- Campos: nombre, ubicación, categoría, calificación, etc.

**Query: Get User by Email**
- Tabla: `usuarios`
- Tipo: Get Row Where
- Condición: email = [email del usuario]

**Query: Get Reviews by Restaurant**
- Tabla: `resenas`
- Tipo: Get Rows Where
- Condición: restaurant_id = [ID del restaurante]

---

## PARTE 3: Configurar Autenticación OTP

### Paso 3.1: Habilitar Autenticación
1. Ve a **"Backend"** → **"Authentication"**
2. Haz clic en **"+ Add Authentication"**
3. Selecciona **"Email/Password"** (para OTP usaremos una solución alternativa)

**Nota**: FlutterFlow no tiene OTP nativo, pero usaremos:
- **Opción A**: Email/Password simple (más fácil)
- **Opción B**: Integrar Twilio para SMS OTP (requiere API key)

### Paso 3.2: Usar Email/Password (Recomendado para MVP)
1. En Authentication, selecciona **"Email/Password"**
2. Habilita **"Allow user sign up"**
3. Configura:
   - Require email verification: **ON**
   - Password requirements: Mínimo 8 caracteres
4. Haz clic en **"Save"**

### Paso 3.3: Crear Tabla de Usuarios en Firebase
FlutterFlow usa Firebase automáticamente. Verifica que exista la colección `users` con campos:
- `email` (string)
- `password` (encriptada automáticamente)
- `nombre` (string)
- `preferencias` (array)
- `ubicacion` (geopoint)

---

## PARTE 4: Crear Pantallas Principales

### Pantalla 1: Login / Registro

**Estructura:**
\`\`\`
LoginScreen
├── Logo (Image)
├── Email TextField
├── Password TextField
├── "Iniciar Sesión" Button
├── "¿No tienes cuenta? Regístrate" Link
└── Loading Indicator
\`\`\`

**Pasos en FlutterFlow:**
1. Haz clic en **"+ Add Page"**
2. Nombre: **"LoginScreen"**
3. Selecciona **"Blank"**
4. Agrega componentes:
   - **Image**: Logo de tu app (200x200)
   - **TextField**: Email (hint: "Correo electrónico")
   - **TextField**: Password (obscure text: ON)
   - **Button**: "Iniciar Sesión"
   - **Text**: "¿No tienes cuenta? Regístrate"

**Acciones del Botón:**
1. Haz clic en el botón "Iniciar Sesión"
2. En el panel derecho, ve a **"Actions"**
3. Haz clic en **"+ Add Action"**
4. Selecciona **"Authentication"** → **"Sign In"**
5. Configura:
   - Email: `emailController.text`
   - Password: `passwordController.text`
6. En "Success": Navega a **"HomeScreen"**
7. En "Error": Muestra alerta con el error

---

### Pantalla 2: Registro

**Estructura:**
\`\`\`
SignUpScreen
├── Logo (Image)
├── Nombre TextField
├── Email TextField
├── Password TextField
├── Confirmar Password TextField
├── "Crear Cuenta" Button
└── "¿Ya tienes cuenta? Inicia sesión" Link
\`\`\`

**Pasos:**
1. Agrega nueva página: **"SignUpScreen"**
2. Agrega los mismos componentes que LoginScreen + Nombre
3. En el botón "Crear Cuenta":
   - Acción: **"Authentication"** → **"Sign Up"**
   - Configura email, password
   - En Success: Navega a **"ProfileScreen"**

---

### Pantalla 3: Perfil y Preferencias

**Estructura:**
\`\`\`
ProfileScreen
├── Header
│   ├── Nombre del usuario
│   └── Email
├── Preferencias
│   ├── Categorías (Checkboxes)
│   ├── Rango de precios (Slider)
│   └── Radio de búsqueda (Slider)
├── "Guardar Cambios" Button
└── "Cerrar Sesión" Button
\`\`\`

**Pasos:**
1. Agrega página: **"ProfileScreen"**
2. Agrega componentes:
   - **Text**: Nombre del usuario (vinculado a `currentUser.displayName`)
   - **Text**: Email (vinculado a `currentUser.email`)
   - **Checkboxes**: Categorías (Italiana, Mexicana, Asiática, etc.)
   - **Slider**: Rango de precios (0-100)
   - **Slider**: Radio de búsqueda (1-50 km)
   - **Button**: "Guardar Cambios"
   - **Button**: "Cerrar Sesión"

**Acciones:**
- Botón "Guardar": Actualiza documento del usuario en Firebase
- Botón "Cerrar Sesión": `Authentication` → `Sign Out` → Navega a LoginScreen

---

### Pantalla 4: Mapa de Restaurantes

**Estructura:**
\`\`\`
HomeScreen
├── Search Bar (Filtros)
├── Google Map
│   └── Markers de restaurantes
├── Lista de restaurantes (debajo del mapa)
│   └── Card de cada restaurante
└── Floating Action Button (Filtros)
\`\`\`

**Pasos:**
1. Agrega página: **"HomeScreen"**
2. Agrega componentes:
   - **TextField**: Búsqueda (hint: "Buscar restaurante...")
   - **Google Map**: 
     - Ve a **"Backend"** → **"API Calls"**
     - Crea API call para Google Maps API
     - Configura markers desde query `getAllRestaurants`
   - **ListView**: Muestra restaurantes en lista
   - **FloatingActionButton**: Abre filtros

**Configurar Mapa:**
1. Selecciona el componente Map
2. En el panel derecho, ve a **"Map Settings"**
3. Configura:
   - Initial Latitude: -34.6037 (ejemplo: Buenos Aires)
   - Initial Longitude: -58.3816
   - Zoom Level: 13
4. En **"Markers"**, vincula a la query `getAllRestaurants`
5. Cada marker muestra: nombre, calificación, distancia

---

### Pantalla 5: Detalles del Restaurante

**Estructura:**
\`\`\`
RestaurantDetailScreen
├── Imagen del restaurante
├── Nombre y calificación
├── Dirección y teléfono
├── Descripción
├── Horario de atención
├── Reseñas (ListView)
├── "Agregar Reseña" Button
├── "Agregar a Favoritos" Button
└── "Volver" Button
\`\`\`

**Pasos:**
1. Agrega página: **"RestaurantDetailScreen"**
2. Recibe parámetro: `restaurantId`
3. Agrega componentes:
   - **Image**: Foto del restaurante
   - **Text**: Nombre (vinculado a `selectedRestaurant.nombre`)
   - **RatingBar**: Calificación (vinculado a `selectedRestaurant.calificacion`)
   - **Text**: Dirección, teléfono, horario
   - **ListView**: Reseñas (query: `getReviewsByRestaurant`)
   - **Button**: "Agregar Reseña"
   - **Button**: "Agregar a Favoritos"

**Acciones:**
- Botón "Agregar Reseña": Navega a **"AddReviewScreen"**
- Botón "Favoritos": Actualiza tabla `historial_interacciones`

---

### Pantalla 6: Agregar Reseña

**Estructura:**
\`\`\`
AddReviewScreen
├── Nombre del restaurante (solo lectura)
├── Rating (1-5 estrellas)
├── Comentario (TextField)
├── "Enviar Reseña" Button
└── "Cancelar" Button
\`\`\`

**Pasos:**
1. Agrega página: **"AddReviewScreen"**
2. Recibe parámetro: `restaurantId`
3. Agrega componentes:
   - **Text**: Nombre del restaurante
   - **RatingBar**: Seleccionar calificación
   - **TextField**: Comentario (multiline)
   - **Button**: "Enviar Reseña"

**Acción del Botón:**
1. Valida que rating y comentario no estén vacíos
2. Crea nuevo registro en tabla `resenas`:
   - `restaurant_id`: parámetro recibido
   - `user_id`: `currentUser.uid`
   - `calificacion`: valor del rating
   - `comentario`: texto del TextField
   - `fecha`: fecha actual
3. En Success: Muestra alerta "Reseña enviada" y vuelve a DetailScreen

---

## PARTE 5: Configurar Navegación

### Paso 5.1: Crear Tab Navigation
1. Ve a **"Navigation"** (parte superior)
2. Selecciona **"Tab Navigation"**
3. Configura 3 tabs:
   - **Tab 1**: "Inicio" → HomeScreen (Icono: home)
   - **Tab 2**: "Favoritos" → FavoritesScreen (Icono: heart)
   - **Tab 3**: "Perfil" → ProfileScreen (Icono: person)

### Paso 5.2: Configurar Rutas
1. En **"Navigation"**, agrega rutas para:
   - LoginScreen (ruta inicial)
   - SignUpScreen
   - HomeScreen (después de login)
   - RestaurantDetailScreen (con parámetro)
   - AddReviewScreen (con parámetro)

### Paso 5.3: Configurar Redirecciones
1. En **"App Settings"** → **"Initial Route"**
2. Configura lógica:
   - Si usuario está autenticado → HomeScreen
   - Si no → LoginScreen

---

## PARTE 6: Integrar Google Maps API

### Paso 6.1: Obtener API Key de Google Maps
1. Ve a **Google Cloud Console** (console.cloud.google.com)
2. Crea nuevo proyecto: "LocalMatch"
3. Ve a **"APIs & Services"** → **"Library"**
4. Busca **"Maps SDK for Android"** y habilita
5. Busca **"Maps SDK for iOS"** y habilita
6. Ve a **"Credentials"** → **"+ Create Credentials"**
7. Selecciona **"API Key"**
8. Copia la API Key

### Paso 6.2: Agregar API Key a FlutterFlow
1. En FlutterFlow, ve a **"Settings"** → **"API Keys"**
2. Haz clic en **"+ Add API Key"**
3. Nombre: **"Google Maps"**
4. Pega tu API Key
5. Haz clic en **"Save"**

### Paso 6.3: Configurar Mapa en HomeScreen
1. Selecciona el componente Map
2. En **"Map Settings"**:
   - API Key: Selecciona "Google Maps"
   - Markers: Vincula a `getAllRestaurants`
   - Cada marker muestra: nombre, calificación

---

## PARTE 7: Pruebas y Ajustes

### Paso 7.1: Probar en Dispositivo
1. Haz clic en **"Run"** (parte superior derecha)
2. Selecciona **"Run on Device"**
3. Escanea código QR con tu teléfono
4. Prueba el flujo completo:
   - Registrarse
   - Completar perfil
   - Ver mapa
   - Ver detalles de restaurante
   - Agregar reseña

### Paso 7.2: Ajustes Comunes
- **Mapa no carga**: Verifica API Key de Google Maps
- **Datos no aparecen**: Verifica conexión con Google Sheets
- **Autenticación falla**: Verifica Firebase está habilitado

### Paso 7.3: Publicar App
1. Ve a **"Publish"** (parte superior)
2. Selecciona **"Build"**
3. Elige plataforma: iOS o Android
4. Espera a que se compile
5. Descarga el APK o IPA

---

## Resumen de Pantallas

| Pantalla | Función | Componentes Clave |
|----------|---------|------------------|
| LoginScreen | Iniciar sesión | Email, Password, Button |
| SignUpScreen | Crear cuenta | Email, Password, Nombre |
| ProfileScreen | Editar preferencias | Checkboxes, Sliders, Buttons |
| HomeScreen | Ver restaurantes | Map, ListView, Search |
| RestaurantDetailScreen | Ver detalles | Image, Text, Reviews, Buttons |
| AddReviewScreen | Agregar reseña | Rating, TextField, Button |

---

## Próximos Pasos

Una vez que termines esta configuración:
1. **Paso 3**: Integración de IA (OpenAI para recomendaciones)
2. **Paso 4**: Integración con Make.com (automatizaciones)
3. **Paso 5**: Características avanzadas (geolocalización, filtros avanzados)

¿Necesitas ayuda con algún paso específico?
