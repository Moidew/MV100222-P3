"use client"

import { useState } from "react"
import { NavigationContainer } from "@react-navigation/native"
import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { Ionicons } from "@expo/vector-icons"

// Pantallas
import LoginScreen from "./screens/LoginScreen"
import MapScreen from "./screens/MapScreen"
import RestaurantDetailScreen from "./screens/RestaurantDetailScreen"
import ProfileScreen from "./screens/ProfileScreen"
import ReviewsScreen from "./screens/ReviewsScreen"
import RecommendationsScreen from "./screens/RecommendationsScreen"

const Stack = createNativeStackNavigator()
const Tab = createBottomTabNavigator()

// Navegación de autenticación
function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} />
    </Stack.Navigator>
  )
}

// Navegación principal (después de login)
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName
          if (route.name === "Map") {
            iconName = focused ? "map" : "map-outline"
          } else if (route.name === "Recommendations") {
            iconName = focused ? "sparkles" : "sparkles-outline"
          } else if (route.name === "Profile") {
            iconName = focused ? "person" : "person-outline"
          }
          return <Ionicons name={iconName} size={size} color={color} />
        },
        tabBarActiveTintColor: "#FF6B35",
        tabBarInactiveTintColor: "#999",
        headerShown: true,
      })}
    >
      <Tab.Screen name="Map" component={MapScreen} options={{ title: "Restaurantes" }} />
      <Tab.Screen name="Recommendations" component={RecommendationsScreen} options={{ title: "Recomendaciones" }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: "Mi Perfil" }} />
    </Tab.Navigator>
  )
}

// Stack para detalles (se superpone sobre tabs)
function RootStack() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      {isLoggedIn ? (
        <>
          <Stack.Screen name="MainTabs" component={MainTabs} options={{ animationEnabled: false }} />
          <Stack.Group screenOptions={{ presentation: "modal" }}>
            <Stack.Screen name="RestaurantDetail" component={RestaurantDetailScreen} options={{ title: "Detalles" }} />
            <Stack.Screen name="Reviews" component={ReviewsScreen} options={{ title: "Reseñas" }} />
          </Stack.Group>
        </>
      ) : (
        <Stack.Screen name="Auth" component={AuthStack} options={{ animationEnabled: false }} />
      )}
    </Stack.Navigator>
  )
}

export default function App() {
  return (
    <NavigationContainer>
      <RootStack />
    </NavigationContainer>
  )
}
